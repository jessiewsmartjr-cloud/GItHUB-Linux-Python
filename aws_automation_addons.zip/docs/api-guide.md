# API Guide

## S3
Details on S3 automation functions...

## DynamoDB
CRUD operations...
