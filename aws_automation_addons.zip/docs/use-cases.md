# Use Cases

- Moving files between S3
- ML with SageMaker
- Logging to Redshift